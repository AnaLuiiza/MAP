
public class Pizza {
	 public double preco;
	  public String sabor;
	  public String modelo;
	  public String tipo;

}
